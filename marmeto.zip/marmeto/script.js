document.addEventListener('DOMContentLoaded', function () {
    const cartList = document.getElementById('cart-list');
    const subtotalEl = document.getElementById('subtotal');
    const totalEl = document.getElementById('total');
    const currency = '₹';

    // Fetch data from API
    fetch('https://cdn.shopify.com/s/files/1/0883/2188/4479/files/apiCartData.json?v=1728384889')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            renderCartItems(data.items);
            updateCartTotals(data);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
            cartList.innerHTML = '<p>Failed to load cart items. Please try again later.</p>';
        });

    // Render cart items dynamically
    function renderCartItems(items) {
        cartList.innerHTML = ''; 
        items.forEach(item => {
            const itemEl = document.createElement('div');
            itemEl.classList.add('cart-item');
            itemEl.dataset.itemId = item.id; 
            itemEl.innerHTML = `
                <img src="${item.image}" alt="${item.title}" class="cart-item-image">
                <div class="cart-item-info">
                    <h4>${item.title}</h4>
                    <p>Original Price: <s>${currency}${(item.original_price / 100).toFixed(2)}</s></p>
                    <p>Discounted Price: <strong>${currency}${(item.discounted_price / 100).toFixed(2)}</strong></p>
                    <p>Total Discount: ${currency}${(item.total_discount / 100).toFixed(2)}</p>
                    <input type="number" value="${item.quantity}" min="1" class="quantity-input">
                    <p>Subtotal: <strong>${currency}${(item.line_price / 100).toFixed(2)}</strong></p>
                </div>
                <button class="remove-item">🗑</button>
            `;
            cartList.appendChild(itemEl);

            // Handle quantity change with debounce
            let debounceTimeout;
            itemEl.querySelector('.quantity-input').addEventListener('input', function (event) {
                clearTimeout(debounceTimeout);
                debounceTimeout = setTimeout(() => {
                    const newQuantity = event.target.value;
                    const newLinePrice = newQuantity * (item.discounted_price / 100);
                    itemEl.querySelector('.cart-item-info p:last-child').innerHTML = `Subtotal: <strong>${currency}${newLinePrice.toFixed(2)}</strong>`;
                    item.line_price = newLinePrice * 100; // Update line price
                    updateCartTotals();
                }, 300); 
            });

            // Handle item removal
            itemEl.querySelector('.remove-item').addEventListener('click', function () {
                itemEl.remove();
                updateCartTotals();
            });
        });
    }

    // Update cart totals (subtotal, total, etc.)
    function updateCartTotals() {
        let subtotal = 0;
        document.querySelectorAll('.cart-item').forEach(itemEl => {
            const subtotalText = itemEl.querySelector('.cart-item-info p:last-child').textContent;
            subtotal += parseFloat(subtotalText.replace(`Subtotal: ${currency}`, '').replace(',', '')); // Handle potential comma formatting
        });
        subtotalEl.textContent = `${currency}${subtotal.toFixed(2)}`;
        totalEl.textContent = `${currency}${subtotal.toFixed(2)}`; 
    }
});
